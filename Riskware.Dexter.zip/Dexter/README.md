# Dexter
Dexter v2 - Point of Sales Trojan

Uploaded to GitHub for those want to analyse the code.
